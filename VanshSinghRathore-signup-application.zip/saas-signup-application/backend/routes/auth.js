import express from "express";
import Lead from "../models/Lead.js";
import crypto from "crypto";
import nodemailer from "nodemailer";

const router = express.Router();

router.post("/signup", async (req, res) => {
  const { email } = req.body;
  const token = crypto.randomBytes(20).toString("hex");
  try {
    const lead = new Lead({ email, token });
    await lead.save();
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
    });
    const link = `${process.env.BASE_URL}/verify?token=${token}`;
    await transporter.sendMail({
      to: email,
      subject: "Verify your email",
      html: `<a href="${link}">Click here to verify</a>`,
    });
    res.json({ message: "Check your email for verification link" });
  } catch (e) {
    res.status(400).json({ error: "Email already exists" });
  }
});

router.get("/verify", async (req, res) => {
  const { token } = req.query;
  const lead = await Lead.findOne({ token });
  if (!lead) return res.status(400).send("Invalid token");
  lead.verified = true;
  await lead.save();
  res.redirect("/thankyou.html");
});

export default router;
